void
my_lock(int fd)
{
	return;
}

void
my_unlock(int fd)
{
	return;
}
